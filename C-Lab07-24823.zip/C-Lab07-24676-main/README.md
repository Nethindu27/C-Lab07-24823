# C-Lab07-24676

Question 04:

Declare two single dimensional array with the size given by the user and find, display the followings;
• Scalar Sum (Adding values of each element of an array)
• Vector Sum (Adding values of cach relative elements of an array and store them in third array)
• Vector Product (Multiply values of each relative elements of an array and store them in third array)
• Scalar Product (Multiply values of each relative elements of an array and store them in third array. After placing the values in third array add all the values)

Question 05:

Create a Console application with two classes (Main class + another class).
Inside the main class take a user input which is the size of the array.
Pass the user inserted size as a parameter to the added class method.
Inside the method create an integer array based on passed value from main method
Then take user inputs for the created array inside the separate class.
Every user input value should be followed by value 0 inside the array.

Question 06:

Create a Console application with two added classes called "Animal" and "Dog".
'Dog' is the derived class (Child) of 'Animal Class' (Base Class).
Inside the 'Animal Class' Create a method which for 'Dog' Class.
Inside the method print *I am an Animal",
Inside the "Dog Class" Create a method and display *I have four legs",
Inside the main method create relevant dass object and Display as follows.
"am an animal I have four legs",
